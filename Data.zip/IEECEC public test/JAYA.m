function [bestf,Best,fopt]=JAYA(pop,maxGen,mini,maxi,var,objective)
if size(mini,1)==1  % 由单变量边界转变成向量边界
    mini= mini.*ones(1,var);    % 下界
    maxi= maxi.*ones(1,var);    % 上界
end

%%  产生初始随机种群
for i=1:var
    x(:,i) = mini(i)+(maxi(i)-mini(i))*rand(pop,1);
end
%%  计算随机种群的适应度
for i=1:pop
    f(i) = objective(x(i,:));
end

%%  进入主循环
gen=1;  % 迭代次数
while(gen <= maxGen)
    [row,col]=size(x);
    [t,tindex]=min(f);    % 确定上一轮迭代的最优解
    Best=x(tindex,:);     % 最优解
    [w,windex]=max(f);    % 确定上一轮迭代的最差解
    worst=x(windex,:);    % 最差解
    xnew=zeros(row,col);
    
    for i=1:row  % 位置更新
        for j=1:col
            xnew(i,j)=(x(i,j))+rand*(Best(j)-abs(x(i,j))) - rand*(worst(j)-abs(x(i,j)));  % 通过调节两个rand调整逼近最优解的能力
        end
    end
    
    for i=1:row  % 种群参数越界及新适应度计算
        xnew(i,:) = max(min(xnew(i,:),maxi),mini);
        fnew(i,:) = objective(xnew(i,:));
    end
    
    for i=1:pop  % 全局位置更新
        if(fnew(i)<f(i))
            x(i,:) = xnew(i,:);
            f(i) = fnew(i);
        end
    end
    
    fnew = []; xnew = [];
    [fopt(gen),ind] = min(f);
    xopt(gen,:)= x(ind,:);
    bestf=min(f);
   % disp(['JAYA第',num2str(gen), '次迭代的最优适应度为：',num2str(min(f))])
    gen = gen+1;
end