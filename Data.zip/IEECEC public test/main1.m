%% 清除环境变量
clear
clc
close all
addpath(genpath(pwd));

%% 参数设置
number = 30 ;                                                   %  选定CEC2017优化函数，自行替换 1-30 除了2皆可
variables_no = 30;                                            %  可选 2, 10, 30, 50, 100
[lb,ub,variables_no,fobj]=Get_Functions_cec2017(number,variables_no);  % [lb,ub,D,y]：下界、上界、维度、目标函数表达式
pop_size = 30;                                                %  种群数量 
max_iter = 500;                                               %  迭代次数

%% 运行各算法
[IPO_Best_score,~,IPO_curve] = NCPO(pop_size,max_iter,lb,ub,variables_no,fobj);
[PO_Best_score,~,PO_curve] = PO(pop_size,max_iter,lb,ub,variables_no,fobj);        % 鹦鹉优化算法（2024）
[NRBO_Best_score,~,NRBO_curve] = NRBO(pop_size,max_iter,lb,ub,variables_no,fobj);  % 牛顿-拉夫逊优化算法（2024）
[OOA_Best_score,~,OOA_curve] = OOA(pop_size,max_iter,lb,ub,variables_no,fobj);     % 鱼鹰优化算法（2023）
[KOA_Best_score,~,KOA_curve] = KOA(pop_size,max_iter,lb,ub,variables_no,fobj);     % 开普勒优化算法（2023） 
[SSA_Best_score,~,SSA_curve] = SSA(pop_size,max_iter,lb,ub,variables_no,fobj);     % 麻雀搜索算法（2020）
[JAYA_Best_score,~,JAYA_curve] = JAYA(pop_size,max_iter,lb,ub,variables_no,fobj);  % JAYA优化算法（2015）

%% 显示结果
display(['NCPO在函数' [num2str(number)],'上的最优值', num2str(IPO_Best_score)]);
display(['PO在函数' [num2str(number)],'上的最优值', num2str(PO_Best_score)]);
display(['NRBO在函数' [num2str(number)],'上的最优值', num2str(NRBO_Best_score)]);
display(['OOA在函数' [num2str(number)],'上的最优值', num2str(OOA_Best_score)]);
display(['KOA在函数' [num2str(number)],'上的最优值', num2str(KOA_Best_score)]);
display(['SSA在函数' [num2str(number)],'上的最优值', num2str(SSA_Best_score)]);
display(['JAYA在函数' [num2str(number)],'上的最优值', num2str(JAYA_Best_score)]);

%% 画图
figure1 = figure('Color',[1 1 1]);
G1=subplot(1,2,1,'Parent',figure1);
func_plot2017(number,variables_no)
xlabel('x')
ylabel('y')
zlabel('z')
subplot(1,2,2)
G2=subplot(1,2,2,'Parent',figure1);
CNT=30;% 绘图点的数目
k=round(linspace(1,max_iter,CNT));       % 随机选CNT个点
% 注意：如果收敛曲线画出来的点很少，随机点很稀疏，说明点取少了，这时应增加取点的数量，100、200、300等，逐渐增加
% 相反，如果收敛曲线上的随机点非常密集，说明点取多了，此时要减少取点数量
iter=1:1:max_iter;
    semilogy(iter(k),IPO_curve(k),'r-o','linewidth',1);
    hold on
    semilogy(iter(k),PO_curve(k),'b-^','linewidth',1);
    hold on
    semilogy(iter(k),NRBO_curve(k),'g-+','linewidth',1);
    hold on
    semilogy(iter(k),OOA_curve(k),'m-*','linewidth',1);
    hold on
    semilogy(iter(k),KOA_curve(k),'y-p','linewidth',1);
    hold on
    semilogy(iter(k),SSA_curve(k),'c-d','linewidth',1);
    hold on
    semilogy(iter(k),JAYA_curve(k),'k-s','linewidth',1);
grid on;
title('F Convergence Curve') % Convergence Curve 收敛曲线
xlabel('Iteration');% Iteration# 迭代次数
ylabel('Fitness Value');% Fitness Value 适应度值
box on
t=legend('NCPO','PO','NRBO','OOA','KOA','SSA','JAYA');
t.NumColumns=2;%设置属性中列个数为2
t.Location='best';%将图例在窗口最佳位置
set(gcf,'color','w')
set (gcf,'position', [300,300,800,330])

rmpath(genpath(pwd))


