%% 清除环境变量
clear
clc
close all
addpath(genpath(pwd));

%% 参数设置
pop_size = 30;                        %  种群数目
max_iter = 500;                       %  迭代次数
run = 5;                              %  每种算法运行几次
box_pp = 1;                           %  等于1，绘制箱型图，否则不绘制
RESULT = [];                          %  存储标准差，平均值，最优值等结果
rank_sum_RESULT = [];                 %  存储秩和检验结果

F = [ 1 ];   %  第二个函数被删了 选定CEC2017优化函数，自行替换 1-29 除了2皆可
variables_no = 30;                    %  维度可选 2, 10, 30, 50, 100
disp(['正在统计的是维度为',num2str(variables_no),'的CEC2017函数集'])

if box_pp ==1
    figure('Name', '箱型图', 'Color', 'w','Position', [50 50 1400 700])
end

for func_num = 1:length(F)    
    disp(['F',num2str(F(func_num)),'函数计算结果：'])
    num=F(func_num);
    [lb,ub,variables_no,fhd] = Get_Functions_cec2017(num,variables_no);
    resu = [];                        %  存储标准差，平均值，最优值等结果
    rank_sum_resu = [];               %  存储秩和检验结果
    box_plot = [];                    %  存储箱型图结果
    
    %% 运行NCPO算法
    for nrun=1:run
        [final,position,iter] = NCPO(pop_size,max_iter,lb,ub,variables_no,fhd);
        final_main(nrun)=final;
        z1(nrun) =  final;
    end
    box_plot = [box_plot;final_main];
    zz = [min(final_main);std(final_main);mean(final_main);median(final_main);max(final_main)];
    resu = [resu,zz];
    disp(['NCPO：最优值:',num2str(zz(1)),' 标准差:',num2str(zz(2)),' 平均值:',num2str(zz(3)),' 中值:',num2str(zz(4)),' 最差值:',num2str(zz(5))]);
    
    %% 运行PO算法
    for nrun=1:run
        [final,position,iter] = PO(pop_size,max_iter,lb,ub,variables_no,fhd);
        final_main(nrun)=final;
        z2(nrun) =  final;
    end
    box_plot = [box_plot;final_main]; %统计箱型图结果
    zz = [min(final_main);std(final_main);mean(final_main);median(final_main);max(final_main)];
    resu = [resu,zz];
    rs = ranksum(z1,z2);
    if isnan(rs)  %当z1与z2完全一致时会出现NaN值，这种概率很小，但是要做一个防止报错
        rs=1;
    end
    rank_sum_resu = [rank_sum_resu,rs]; %统计秩和检验结果
    disp(['PO：最优值:',num2str(zz(1)),' 标准差:',num2str(zz(2)),' 平均值:',num2str(zz(3)),' 中值:',num2str(zz(4)),' 最差值:',num2str(zz(5))]);

    %% 运行NRBO算法
    for nrun=1:run
        [final,position,iter] = NRBO(pop_size,max_iter,lb,ub,variables_no,fhd);
        final_main(nrun)=final;
        z2(nrun) =  final;
    end
    box_plot = [box_plot;final_main]; %统计箱型图结果
    zz = [min(final_main);std(final_main);mean(final_main);median(final_main);max(final_main)];
    resu = [resu,zz];
    rs = ranksum(z1,z2);
    if isnan(rs)  %当z1与z2完全一致时会出现NaN值，这种概率很小，但是要做一个防止报错
        rs=1;
    end
    rank_sum_resu = [rank_sum_resu,rs]; %统计秩和检验结果
    disp(['NRBO：最优值:',num2str(zz(1)),' 标准差:',num2str(zz(2)),' 平均值:',num2str(zz(3)),' 中值:',num2str(zz(4)),' 最差值:',num2str(zz(5))]);


    %% 运行OOA算法
    for nrun=1:run
        [final,position,iter] = OOA(pop_size,max_iter,lb,ub,variables_no,fhd);
        final_main(nrun)=final;
        z2(nrun) =  final;
    end
    box_plot = [box_plot;final_main]; %统计箱型图结果
    zz = [min(final_main);std(final_main);mean(final_main);median(final_main);max(final_main)];
    resu = [resu,zz];
    rs = ranksum(z1,z2);
    if isnan(rs)  %当z1与z2完全一致时会出现NaN值，这种概率很小，但是要做一个防止报错
        rs=1;
    end
    rank_sum_resu = [rank_sum_resu,rs]; %统计秩和检验结果
    disp(['OOA：最优值:',num2str(zz(1)),' 标准差:',num2str(zz(2)),' 平均值:',num2str(zz(3)),' 中值:',num2str(zz(4)),' 最差值:',num2str(zz(5))]);
    
    %% 运行KOA算法
    for nrun=1:run
        [final,position,iter] = KOA(pop_size,max_iter,lb,ub,variables_no,fhd);

        final_main(nrun)=final;
        z2(nrun) =  final;

    end
    box_plot = [box_plot;final_main]; %统计箱型图结果
    zz = [min(final_main);std(final_main);mean(final_main);median(final_main);max(final_main)];
    resu = [resu,zz];
    rs = ranksum(z1,z2);
    if isnan(rs)  %当z1与z2完全一致时会出现NaN值，这种概率很小，但是要做一个防止报错
        rs=1;
    end
    rank_sum_resu = [rank_sum_resu,rs]; %统计秩和检验结果
    disp(['KOA：最优值:',num2str(zz(1)),' 标准差:',num2str(zz(2)),' 平均值:',num2str(zz(3)),' 中值:',num2str(zz(4)),' 最差值:',num2str(zz(5))]);

    %% 运行SSA算法
    for nrun=1:run
        [final,position,iter] = SSA(pop_size,max_iter,lb,ub,variables_no,fhd);
        final_main(nrun)=final;
        z2(nrun) =  final;

    end
    box_plot = [box_plot;final_main]; %统计箱型图结果
    zz = [min(final_main);std(final_main);mean(final_main);median(final_main);max(final_main)];
    resu = [resu,zz];
    rs = ranksum(z1,z2);
    if isnan(rs)  %当z1与z2完全一致时会出现NaN值，这种概率很小，但是要做一个防止报错
        rs=1;
    end
    rank_sum_resu = [rank_sum_resu,rs]; %统计秩和检验结果
    disp(['SSA：最优值:',num2str(zz(1)),' 标准差:',num2str(zz(2)),' 平均值:',num2str(zz(3)),' 中值:',num2str(zz(4)),' 最差值:',num2str(zz(5))]);

    %% 运行JAYA算法
    for nrun=1:run
        [final,position,iter] = JAYA(pop_size,max_iter,lb,ub,variables_no,fhd);
        final_main(nrun)=final;
        z2(nrun) =  final;

    end
    box_plot = [box_plot;final_main]; %统计箱型图结果
    zz = [min(final_main);std(final_main);mean(final_main);median(final_main);max(final_main)];
    resu = [resu,zz];
    rs = ranksum(z1,z2);
    if isnan(rs)  %当z1与z2完全一致时会出现NaN值，这种概率很小，但是要做一个防止报错
        rs=1;
    end
    rank_sum_resu = [rank_sum_resu,rs]; %统计秩和检验结果
    disp(['JAYA：最优值:',num2str(zz(1)),' 标准差:',num2str(zz(2)),' 平均值:',num2str(zz(3)),' 中值:',num2str(zz(4)),' 最差值:',num2str(zz(5))]);


    rank_sum_RESULT = [rank_sum_RESULT;rank_sum_resu];   %  统计秩和检验结果
    RESULT = [RESULT;resu];                              %  统计标准差，平均值，最优值等结果
    
    %% 绘制箱型图
    if box_pp == 1 
        subplot(5,6,func_num)  %4行6列
        mycolor = [0.862745098039216,0.827450980392157,0.117647058823529;...
        0.705882352941177,0.266666666666667,0.423529411764706;...
        0.949019607843137,0.650980392156863,0.121568627450980;...
        0.956862745098039,0.572549019607843,0.474509803921569;...
        0.231372549019608,0.490196078431373,0.717647058823529];  %设置一个颜色库
        %% 开始绘图
        %参数依次为数据矩阵、颜色设置、标记符
        box_figure = boxplot(box_plot','color',[0 0 0],'Symbol','o');
        %设置线宽
        set(box_figure,'Linewidth',1.2);
        boxobj = findobj(gca,'Tag','Box');
        for i = 1:5
            patch(get(boxobj(i),'XData'),get(boxobj(i),'YData'),mycolor(i,:),'FaceAlpha',0.5,...
                'LineWidth',1.1);
        end
        set(gca,'XTickLabel',{'NCPO','PO','NRBO','OOA','KOA','SSA','JAYA'});
        title(['F',num2str(F(func_num))])
        hold on
        xlabel('Algorithms','Fontsize',10,'FontWeight','bold','FontName','Times New Roman');%% 设置坐标区域的参数
        ylabel('Fitness','Fontsize',10,'FontWeight','bold','FontName','Times New Roman');

    end 
end

if exist('指标结果.xlsx','file')
    delete('指标结果.xlsx')
end

if exist('秩和检验结果.xlsx','file')
    delete('秩和检验结果.xlsx')
end

%%  将标准差，平均值，最优值等结果写入Excel中
A = string();
for i = 1:length(F)
    str = string(['F',num2str(F(i))]);
    A(5*(i-1)+1:5*i,1)= [str,str,str,str,str];
    A(5*(i-1)+1:5*i,2)= ["最优值";"标准差";"平均值";"中值";"最差值"];%Best Std Mean Median Mean Worst
end
A = cellstr (A);
A = [A,num2cell(RESULT)];
title = {" "," ","NCPO", "PO", "NRBO", "OOA", "KOA", "SSA", "JAYA"};
A = [title;A];
xlswrite('指标结果.xlsx', A)

%%  将秩和检验结果写入Excel中
B = string();
for i = 1:length(F)
    str = string(['F',num2str(F(i))]);
    B(i,1)= str;
end
B = cellstr (B);
B = [B,num2cell(rank_sum_RESULT)];
title = {" ", "PO", "NRBO", "OOA", "KOA", "SSA", "JAYA"};
B = [title;B];
xlswrite('秩和检验结果.xlsx', B)

%%  Friedman检验
selected_rows = [];
for i = 1:numel(F)
    selected_rows = [selected_rows, 3 + (i-1)*5];
end
average = RESULT(selected_rows, :);
[p,tbl,stats] = friedman(average); % 计算Friedman值
% 输出每个算法的平均排名
algorithms = {"NCPO", "PO", "NRBO", "OOA", "KOA", "SSA", "JAYA"};
for i = 1:numel(algorithms)
    fprintf('%s算法的Friedman检验平均排名为：%f\n', algorithms{i}, stats.meanranks(i)); 
end
disp(['Friedman检验的p值为：', num2str(p)]);
C = num2cell(stats.meanranks);
C = [algorithms;C];
% 将数据写入 Excel 文件
xlswrite('Friedman检验结果.xlsx', C)
