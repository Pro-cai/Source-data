
function [Best_score,Best_pos, curve] = IPO(N, Max_iter, lb, ub, dim, fobj)

% BestF: Best value in a certain iteration
% WorstF: Worst value in a certain iteration
% GBestF: Global best fitness value
% AveF: Average value in each iteration

if (max(size(ub)) == 1)
    ub = ub .* ones(1, dim);
    lb = lb .* ones(1, dim);
end

%% Initialization
X0 = initialization(N, dim, ub, lb); % Initialization
X = X0;

% Compute initial fitness values
fitness = zeros(1, N);
for i = 1:N
    fitness(i) = fobj(X(i, :));
end
[fitness, index] = sort(fitness); % sort
GBestF = fitness(1); % Global best fitness value
for i = 1:N
    X(i, :) = X0(index(i), :);
end
curve = zeros(1, Max_iter);
GBestX = X(1, :); % Global best position
GWorstX = X(end, :); % Global worst position
X_new = X;

%% Start search
for t = 1 : Max_iter
    t
    alpha = rand(1) / 5;
    %sita = rand(1) * pi;
    for i = 1 : N
        St = randi([1, 4]);
        % foraging behavior
        if St == 1
                X_new(i, :) = (X(i, :) - GBestX) .* Levy(dim) + rand(1) * mean(X(i, :)) * (1 - t / Max_iter) ^ (2 * t / Max_iter);

        % staying behavior
        elseif St == 2
                Q = rand(1);
                if Q < 0.8
                    X_new(i, :) = X(i, :) + GBestX .* Levy(dim) + randn() * (1 - t / Max_iter) * ones(1, dim);
                else
                    %%  正态云模型
                    Ex = GBestX;                 %  正态云期望
                    En = exp(t / Max_iter);      %  正态云熵
                    He = En/10^(-3);             %  正态云超熵
                    E_n = normrnd(En, He);       %  生成正态分布随机数
                    ra= normrnd(Ex, abs(E_n));   %  生成正态随机数
                    X_new(i, :)= exp(- (ra- Ex).^ 2 / (2 * E_n^2));      % 计算隶属度函数
                end
        % communicating behavior
        elseif St == 3
                H = rand(1);
                if H < 0.5
                    X_new(i, :) = X(i, :) + alpha * (1 - t / Max_iter) * (X(i, :) - mean(X(i, :)));
                else
                    X_new(i, :) = X(i, :) + alpha * (1 - t / Max_iter) * exp(-i / (rand(1) * Max_iter));
                end
        % fear of strangers' behavior
        else
           
                X_new(i, :) = (X(i, :)) + rand * (GBestX - abs(X(i, :))) - rand * (GWorstX - abs(X(i, :)));  % 通过调节两个rand调整逼近最优解的能力
        end

        X_new(i, :) = Bounds(X_new(i, :), lb, ub);
    
        % Update positions
        for i = 1: N
            fitness_new(i) = fobj(X_new(i, :));
        end
        for i = 1: N
            if (fitness_new(i) < GBestF)
                GBestF = fitness_new(i);
                GBestX = X_new(i, :);
            end
        end
        
        %%  警戒机制
        [fmax,~]=max(fitness_new); % 确定当前代中最差的适应度
        c=randperm(N);
        b=c(1:N);
        for i = 1:length(b)
            if( fitness_new(b(i))>GBestF)
                X_new(b(i),:)=GBestX+(randn(1,dim)).*(abs((X_new(b(i),:)-GBestX)));
                % 如果当前个体大于最优个体，则位置=最优位置+正态分布随机数*|当前位置-最优位置|
            else
                X_new(b(i),:)=X_new(b(i),:)+(2*rand(1)-1)*(abs(X_new(b(i),:)-GWorstX))/(fitness_new(b(i))-fmax+1e-50);
                %否则，位置=当前位置+[-1,1]的随机数*|当前位置-最差位置|/当前位置适应度值与最差位置适应度值的差
            end

            X_new(b(i), :) = Bounds(X_new(b(i), :), lb, ub);

            fitness_new(b(i))=fobj(X_new(b(i),:));
        end
        if (fitness_new(i) < GBestF)
            GBestF = fitness_new(i);
            GBestX = X_new(i, :);
        end

        X = X_new;
        curve(t) = GBestF;    
    end
    Best_pos = GBestX;
    Best_score = curve(end);
end
end

%%  Levy search strategy
function o = Levy(d)
    beta = 1.5;
    sigma = (gamma(1 + beta) *sin(pi * beta / 2) / (gamma((1 + beta) / 2) * beta * 2^((beta - 1) / 2)))^(1 / beta);
    u = randn(1, d) * sigma;
    v = randn(1, d);
    step = u ./ abs(v).^(1 / beta);
    o = step;
end   

function S = Bounds( SS, LLb, UUb)
  % Apply the lower bound vector
  % Apply the lower bound vector
  temp = SS;
  I = temp < LLb;
  temp(I) = LLb(I);
  
  % Apply the upper bound vector 
  i = temp > UUb;
  temp(i) = UUb(i);
  % Update this new move 
  S = temp;
end
